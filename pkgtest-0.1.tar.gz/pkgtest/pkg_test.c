#include <stdio.h>
#include <stdlib.h>

int
main (int argc, char** argv)
{
    printf("\nDies ist ein Test\n");
    return EXIT_SUCCESS;
}
